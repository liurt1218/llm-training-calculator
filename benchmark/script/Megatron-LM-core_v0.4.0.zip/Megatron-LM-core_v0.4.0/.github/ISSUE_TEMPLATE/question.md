---
name: QUESTION
about: Ask a question about Megatron-LM that is not a bug, regression or enhancement
  request
title: "[QUESTION]"
labels: ''
assignees: ''

---

**Your question**
Ask a clear and concise question about Megatron-LM.
