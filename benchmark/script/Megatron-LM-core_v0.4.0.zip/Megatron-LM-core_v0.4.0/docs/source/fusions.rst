fusions package
===============

Submodules
----------

fusions.fused\_bias\_dropout module
-----------------------------------

.. automodule:: fusions.fused_bias_dropout
   :members:
   :undoc-members:
   :show-inheritance:

fusions.fused\_bias\_gelu module
--------------------------------

.. automodule:: fusions.fused_bias_gelu
   :members:
   :undoc-members:
   :show-inheritance:

fusions.fused\_layer\_norm module
---------------------------------

.. automodule:: fusions.fused_layer_norm
   :members:
   :undoc-members:
   :show-inheritance:

fusions.fused\_softmax module
-----------------------------

.. automodule:: fusions.fused_softmax
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: fusions
   :members:
   :undoc-members:
   :show-inheritance:
