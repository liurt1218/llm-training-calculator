API Guide
=========

.. toctree::
   :maxdepth: 4

   models
   tensor_parallel
   pipeline_parallel
   fusions
   transformer
   dist_checkpointing
