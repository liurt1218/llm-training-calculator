tensor\_parallel package
========================

Submodules
----------

tensor\_parallel.cross\_entropy module
--------------------------------------

.. automodule:: tensor_parallel.cross_entropy
   :members:
   :undoc-members:
   :show-inheritance:

tensor\_parallel.data module
----------------------------

.. automodule:: tensor_parallel.data
   :members:
   :undoc-members:
   :show-inheritance:

tensor\_parallel.layers module
------------------------------

.. automodule:: tensor_parallel.layers
   :members:
   :undoc-members:
   :show-inheritance:

tensor\_parallel.mappings module
--------------------------------

.. automodule:: tensor_parallel.mappings
   :members:
   :undoc-members:
   :show-inheritance:

tensor\_parallel.random module
------------------------------

.. automodule:: tensor_parallel.random
   :members:
   :undoc-members:
   :show-inheritance:

tensor\_parallel.utils module
-----------------------------

.. automodule:: tensor_parallel.utils
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: tensor_parallel
   :members:
   :undoc-members:
   :show-inheritance:
