transformer package
===================

Submodules
----------

transformer.attention module
----------------------------

.. automodule:: transformer.attention
   :members:
   :undoc-members:
   :show-inheritance:

transformer.dot\_product\_attention module
------------------------------------------

.. automodule:: transformer.dot_product_attention
   :members:
   :undoc-members:
   :show-inheritance:

transformer.enums module
------------------------

.. automodule:: transformer.enums
   :members:
   :undoc-members:
   :show-inheritance:

transformer.identity\_op module
-------------------------------

.. automodule:: transformer.identity_op
   :members:
   :undoc-members:
   :show-inheritance:

transformer.mlp module
----------------------

.. automodule:: transformer.mlp
   :members:
   :undoc-members:
   :show-inheritance:

transformer.module module
-------------------------

.. automodule:: transformer.module
   :members:
   :undoc-members:
   :show-inheritance:

transformer.transformer\_block module
-------------------------------------

.. automodule:: transformer.transformer_block
   :members:
   :undoc-members:
   :show-inheritance:

transformer.transformer\_config module
--------------------------------------

.. automodule:: transformer.transformer_config
   :members:
   :undoc-members:
   :show-inheritance:

transformer.transformer\_layer module
-------------------------------------

.. automodule:: transformer.transformer_layer
   :members:
   :undoc-members:
   :show-inheritance:

transformer.utils module
------------------------

.. automodule:: transformer.utils
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: transformer
   :members:
   :undoc-members:
   :show-inheritance:
